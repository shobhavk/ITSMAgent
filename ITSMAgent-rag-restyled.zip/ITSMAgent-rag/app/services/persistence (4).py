"""
persistence.py
---------------
Persistent storage for the ITSM Quality Analysis app.

Purpose:
  When a user uploads a file, we hash its raw bytes. If we've already
  processed a file with that exact hash, we return the stored results
  directly from the DB instead of re-running classification/scoring
  through the LLM pipeline (LangGraph classify + score nodes).

Storage: SQLite via SQLAlchemy (file-based, no extra infra).
  - Mount the DB file on a Docker volume so it survives container
    restarts, e.g.:
      volumes:
        - itsm_db_data:/app/data
    and point DB_PATH at /app/data/itsm_analysis.db in that environment.

Design notes:
  - Dedup key is SHA-256 of the raw uploaded file bytes -> exact-file
    duplicate detection (not near-duplicate / fuzzy matching).
  - Full processed DataFrame is stored as JSON (records orient) so it
    round-trips exactly, including any truncated/full text columns.
  - We also store which config flags were active (e.g.
    ENABLE_LLM_WORKLOG_SCORING) when the file was processed. If the
    current config no longer matches, the cache is treated as stale
    so results aren't silently wrong after a config change.
"""

import hashlib
import json
import os
from datetime import datetime, timezone
from typing import Optional

import pandas as pd
from sqlalchemy import (
    create_engine,
    Column,
    Integer,
    String,
    Boolean,
    DateTime,
    Text,
    Float,
    UniqueConstraint,
)
from sqlalchemy.orm import declarative_base, sessionmaker

DB_PATH = os.environ.get("ITSM_DB_PATH", "./data/itsm_analysis.db")
os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)

engine = create_engine(f"sqlite:///{DB_PATH}", connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()


class UploadedFile(Base):
    __tablename__ = "uploaded_files"

    id = Column(Integer, primary_key=True)
    file_hash = Column(String(64), unique=True, nullable=False, index=True)
    filename = Column(String(512), nullable=False)
    uploaded_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    ticket_count = Column(Integer, default=0)

    # Config snapshot at time of processing — used to invalidate cache
    # if the pipeline behavior has since changed.
    llm_worklog_scoring_enabled = Column(Boolean, default=False)
    pipeline_version = Column(String(64), default="v1")

    # Full result set, exact round-trip (pandas records-orient JSON).
    results_json = Column(Text, nullable=False)

    __table_args__ = (UniqueConstraint("file_hash", name="uq_file_hash"),)


class TicketCache(Base):
    """
    Real duplicate detection: keyed on Incident/Ticket ID, not file hash.
    Whenever a ticket with this exact ID and unchanged content has been
    analyzed before - in ANY upload, not just an identical file - the
    pipeline reuses this row instead of calling the LLM again for that
    ticket. content_hash guards against silently serving stale results
    if the same Incident ID was re-exported with edited text.
    """
    __tablename__ = "ticket_cache"

    ticket_id = Column(String(128), primary_key=True)
    content_hash = Column(String(64), nullable=False)
    category = Column(String(256))
    category_confidence = Column(Float)
    category_method = Column(String(64))
    worklog_score = Column(Integer)
    worklog_flags_json = Column(Text, default="[]")
    host = Column(String(256), nullable=True)
    configuration_item = Column(String(256), nullable=True)
    llm_worklog_scoring_enabled = Column(Boolean, default=False)
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    # Carried through so a cache-hit ticket still has its timestamps for
    # trend/resolution-metric analysis - these describe the ticket itself,
    # not the LLM processing, so they're safe to reuse across re-uploads
    # even though category/score are keyed on unchanged content.
    opened_at = Column(DateTime, nullable=True)
    closed_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, nullable=True)
    resolved_at = Column(DateTime, nullable=True)
    responded_at = Column(DateTime, nullable=True)
    detected_at = Column(DateTime, nullable=True)


Base.metadata.create_all(engine)


def compute_file_hash(file_bytes: bytes) -> str:
    """SHA-256 hash of raw file bytes. Same file contents => same hash,
    regardless of filename or upload time."""
    return hashlib.sha256(file_bytes).hexdigest()


def compute_ticket_content_hash(short_description: str, description: str, worklog: str) -> str:
    """Hash of a ticket's actual content (not its ID) - used to detect
    when an Incident ID has been re-exported with edited text, so the
    cache isn't served stale in that case."""
    raw = f"{short_description or ''}|{description or ''}|{worklog or ''}".encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def get_ticket_cache_bulk(ticket_ids: list[str]) -> dict[str, dict]:
    """One query for a whole batch of ticket IDs, since the pipeline needs
    to check every ticket in an upload, not just one at a time."""
    if not ticket_ids:
        return {}
    session = SessionLocal()
    try:
        rows = session.query(TicketCache).filter(TicketCache.ticket_id.in_(ticket_ids)).all()
        return {
            r.ticket_id: {
                "content_hash": r.content_hash,
                "category": r.category,
                "category_confidence": r.category_confidence,
                "category_method": r.category_method,
                "worklog_score": r.worklog_score,
                "worklog_flags": json.loads(r.worklog_flags_json or "[]"),
                "host": r.host,
                "configuration_item": r.configuration_item,
                "llm_worklog_scoring_enabled": r.llm_worklog_scoring_enabled,
                "opened_at": r.opened_at,
                "closed_at": r.closed_at,
                "created_at": r.created_at,
                "resolved_at": r.resolved_at,
                "responded_at": r.responded_at,
                "detected_at": r.detected_at,
            }
            for r in rows
        }
    finally:
        session.close()


def save_ticket_cache_bulk(entries: list[dict]) -> None:
    """Upserts a batch of freshly-processed tickets into the cache.
    Each entry needs: ticket_id, content_hash, category, category_confidence,
    category_method, worklog_score, worklog_flags, host, configuration_item,
    llm_worklog_scoring_enabled, opened_at, closed_at, created_at,
    resolved_at, responded_at, detected_at (the last six may be None)."""
    if not entries:
        return
    session = SessionLocal()
    try:
        existing_by_id = {
            r.ticket_id: r
            for r in session.query(TicketCache)
            .filter(TicketCache.ticket_id.in_([e["ticket_id"] for e in entries]))
            .all()
        }
        for e in entries:
            row = existing_by_id.get(e["ticket_id"])
            if row is None:
                row = TicketCache(ticket_id=e["ticket_id"])
                session.add(row)
            row.content_hash = e["content_hash"]
            row.category = e["category"]
            row.category_confidence = e["category_confidence"]
            row.category_method = e["category_method"]
            row.worklog_score = e["worklog_score"]
            row.worklog_flags_json = json.dumps(e["worklog_flags"])
            row.host = e["host"]
            row.configuration_item = e["configuration_item"]
            row.llm_worklog_scoring_enabled = e["llm_worklog_scoring_enabled"]
            row.opened_at = e.get("opened_at")
            row.closed_at = e.get("closed_at")
            row.created_at = e.get("created_at")
            row.resolved_at = e.get("resolved_at")
            row.responded_at = e.get("responded_at")
            row.detected_at = e.get("detected_at")
            row.updated_at = datetime.now(timezone.utc)
        session.commit()
    finally:
        session.close()


def get_cached_result(
    file_hash: str,
    current_llm_worklog_scoring_enabled: Optional[bool] = None,
) -> Optional[dict]:
    """
    Returns a dict {"full_df": DataFrame, "summary_stats": dict,
    "category_counts": dict, "uploaded_at": str} if this exact file has
    been processed before AND the relevant config hasn't changed since.
    Returns None on cache miss or config mismatch (caller should then
    run the normal LLM pipeline).
    """
    session = SessionLocal()
    try:
        record = session.query(UploadedFile).filter_by(file_hash=file_hash).first()
        if record is None:
            return None

        if (
            current_llm_worklog_scoring_enabled is not None
            and record.llm_worklog_scoring_enabled != current_llm_worklog_scoring_enabled
        ):
            # Config changed since this file was last processed —
            # treat as a miss so results reflect current settings.
            return None

        payload = json.loads(record.results_json)
        return {
            "full_df": pd.DataFrame(payload["full_df"]),
            "summary_stats": payload["summary_stats"],
            "category_counts": payload["category_counts"],
            "host_counts": payload.get("host_counts", {}),
            "uploaded_at": record.uploaded_at.isoformat(),
        }
    finally:
        session.close()


def save_result(
    file_hash: str,
    filename: str,
    full_df: pd.DataFrame,
    summary_stats: dict,
    category_counts: dict,
    host_counts: dict,
    llm_worklog_scoring_enabled: bool = False,
    pipeline_version: str = "v1",
) -> None:
    """Persist processed results for a newly-analyzed file. full_df should
    be the untruncated result set (same shape used for CSV export) so the
    cached load can rebuild the on-screen truncated view from it."""
    payload = json.dumps(
        {
            "full_df": json.loads(full_df.to_json(orient="records")),
            "summary_stats": summary_stats,
            "category_counts": category_counts,
            "host_counts": host_counts,
        }
    )

    session = SessionLocal()
    try:
        existing = session.query(UploadedFile).filter_by(file_hash=file_hash).first()
        if existing:
            # Same hash re-saved (e.g. forced re-run) — overwrite in place.
            existing.results_json = payload
            existing.ticket_count = len(full_df)
            existing.llm_worklog_scoring_enabled = llm_worklog_scoring_enabled
            existing.pipeline_version = pipeline_version
            existing.uploaded_at = datetime.now(timezone.utc)
        else:
            record = UploadedFile(
                file_hash=file_hash,
                filename=filename,
                ticket_count=len(full_df),
                llm_worklog_scoring_enabled=llm_worklog_scoring_enabled,
                pipeline_version=pipeline_version,
                results_json=payload,
            )
            session.add(record)

        session.commit()
    finally:
        session.close()


def file_metadata(file_hash: str) -> Optional[dict]:
    """Small helper for surfacing 'this file was already processed on X' in the UI."""
    session = SessionLocal()
    try:
        record = session.query(UploadedFile).filter_by(file_hash=file_hash).first()
        if record is None:
            return None
        return {
            "filename": record.filename,
            "uploaded_at": record.uploaded_at.isoformat(),
            "ticket_count": record.ticket_count,
        }
    finally:
        session.close()
