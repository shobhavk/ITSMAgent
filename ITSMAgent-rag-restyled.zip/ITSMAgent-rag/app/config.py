"""
Central configuration. Everything secret/environment-specific comes from
environment variables (.env locally, real env vars / secret manager in
production). Never hardcode API keys, endpoints, or credentials here.
"""
from functools import lru_cache
from typing import Literal

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # --- App ---
    APP_NAME: str = "ITSM Quality Analysis Agent"
    ENV: Literal["dev", "staging", "prod"] = "dev"
    LOG_LEVEL: str = "INFO"

    # --- Security ---
    # Comma-separated list of valid API keys for calling the backend.
    # In prod, back this with a secrets manager / SAP BTP destination service.
    API_KEYS: str = "change-me-local-dev-key"
    ALLOWED_ORIGINS: str = "http://localhost:7860,http://localhost:8000"
    MAX_UPLOAD_MB: int = 15
    RATE_LIMIT: str = "30/minute"

    # --- LLM provider selection ---
    # "sap_genai_hub"  -> uses SAP Generative AI Hub SDK (orchestration/proxy)
    # "openai_compat"  -> any OpenAI-compatible endpoint (incl. internal gateways)
    # "rule_based"     -> no LLM calls at all, pure heuristics (safe default/demo)
    LLM_PROVIDER: Literal["sap_genai_hub", "openai_compat", "rule_based"] = "rule_based"

    # Model identifiers as provisioned in your model catalog / SAP AI Core
    # deployment config. These are names, not endpoints - the SDK/gateway
    # resolves them to actual deployments.
    CHAT_MODEL_NAME: str = "gpt-5.6-luna"
    EMBEDDING_MODEL_NAME: str = "text-embedding-large"

    # SAP AI Core / Generative AI Hub (used only if LLM_PROVIDER=sap_genai_hub)
    AICORE_AUTH_URL: str | None = None
    AICORE_CLIENT_ID: str | None = None
    AICORE_CLIENT_SECRET: str | None = None
    AICORE_BASE_URL: str | None = None
    AICORE_RESOURCE_GROUP: str | None = None

    # Generic OpenAI-compatible gateway (used only if LLM_PROVIDER=openai_compat)
    LLM_BASE_URL: str | None = None
    LLM_API_KEY: str | None = None

    # --- Categorization ---
    SIMILARITY_THRESHOLD: float = 0.35  # min cosine sim to accept embedding match

    # --- Async scale / 429 handling (LangChain-native, see llm_client.py) ---
    # Max retry attempts on rate-limit errors, via LangChain's built-in
    # Runnable.with_retry() - exponential backoff with jitter.
    LLM_RATE_LIMIT_MAX_RETRIES: int = 5
    # How many ticket texts get embedded per underlying API call
    # (LangChain's OpenAIEmbeddings chunk_size). Previously one embedding
    # call was made PER TICKET that fell through keyword rules - at 3k
    # rows with, say, 40% needing embedding matching, that's 1200+
    # separate calls. Batching cuts that to ~1200/EMBEDDING_BATCH_SIZE.
    EMBEDDING_BATCH_SIZE: int = 200
    # Max concurrent in-flight LLM calls when classifying/scoring tickets
    # that keyword rules and embeddings couldn't resolve, and the max
    # concurrency LangGraph uses when batch-processing tickets through the
    # pipeline graph. Bounds concurrency so a 3k-row upload doesn't fire
    # 3000 simultaneous requests (the direct cause of 429s at scale).
    LLM_MAX_CONCURRENCY: int = 10
    # Worklog scoring: the heuristic rubric (scorer.py) always runs and is
    # free/instant. Blending in an LLM judgment on top is OPTIONAL nuance -
    # off by default. Previously this ran unconditionally for every ticket
    # with a worklog, which meant even tickets fully resolved for free by
    # keyword rules still triggered a full extra LLM round-trip just for
    # scoring - the dominant cause of slowness on small batches. Turn this
    # on only if the heuristic score alone isn't good enough for your data.
    ENABLE_LLM_WORKLOG_SCORING: bool = False

    # --- Knowledge Base / RAG (Step 13) ---
    # Chunk size/overlap are in characters, not tokens - simple, fast,
    # and doesn't need a tokenizer dependency just for chunking. Kept
    # configurable here (not hard-coded in knowledge_base.py) per the
    # spec: chunk size and overlap should be tunable without code changes.
    KB_CHUNK_SIZE: int = 1000
    KB_CHUNK_OVERLAP: int = 150
    # Chunks retrieved per query by default - keeps what reaches the LLM
    # small and relevant rather than dumping the whole knowledge base in
    # (see knowledge_base.py's module docstring).
    KB_TOP_K: int = 5
    # Cosine-similarity floor below which a retrieved chunk is treated as
    # not actually relevant - lets the tool say "nothing relevant found"
    # instead of returning weak matches the LLM might present as an answer.
    KB_MIN_RELEVANCE: float = 0.15
    # Separate from MAX_UPLOAD_MB (incident files) - knowledge documents
    # (PDFs especially) are often larger than incident export files.
    KB_MAX_UPLOAD_MB: int = 25


@lru_cache
def get_settings() -> Settings:
    return Settings()
